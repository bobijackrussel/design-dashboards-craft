package com.example.demo.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class NarudzbaFilterDTO {
    // filter po samoj narudžbi
    private String krojacUsername;          // djelimična pretraga po krojaču
    private String klijentUsername;         // djelimična pretraga po klijentu
    private List<String> statusNarudzbe;    // status narudžbe
    private LocalDate rokZaOtkazivanjeDo;  // filter narudžbi do određenog roka otkazivanja
    private LocalDate rokZaIzraduDo;       // filter narudžbi do određenog roka izrade
    private LocalDate datum;
    private LocalDate datumOtkazivanja;
    private Byte uplacenAvans;
    private LocalDate datumZavrsetkaOd;
    private LocalDate datumZavrsetkaDo;



    // ugniježđeni filter za stavke narudžbe
    private StavkaNarudzbeFilterDTO stavkaFilter;
}
