package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class StavkaNarudzbeDTO {
    private Integer id;
    private Integer ponudaId;
    private Integer narudzbaId;
    private Integer redniBroj;
    private Integer kolicina;
    private BigDecimal cijena;
    private LocalDate datumOtkazivanja;
    private Byte uplacenAvans;
    private LocalDate rokZaOtkazivanje;
    private LocalDate rokZaIzradu;

    private String statusStavkeNaziv;
    private Integer mjereId;
    private KrojacDrzavaPonudaResponseDTO krojacDrzavaPonuda;
    private List<ArtikalDodatakResponse> dodaci;
}
