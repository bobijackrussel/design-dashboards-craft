package com.example.demo.dto;

import com.example.demo.entities.StatusNarudzbe;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class CreateNarudzbaRequest {
    public Integer klijentId;
    public Integer krojacId;
    public Byte uplacenAvans; // optional, default 0
    public StatusNarudzbe statusNarudzbeNaziv; // optional (mapira se na StatusStavke)
    public List<StavkaCreateInNarudzba> stavke; // obavezno: lista stavki
}
