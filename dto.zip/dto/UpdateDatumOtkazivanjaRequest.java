package com.example.demo.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class UpdateDatumOtkazivanjaRequest {
    public LocalDate datumOtkazivanja; // može biti null = poništi datum
}
