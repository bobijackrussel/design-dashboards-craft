package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArtikalResponseDTO {
    private Integer id;
    private String naziv;
    private String velicina;
    private Integer kolicina;
    private String bojaNaziv;
    private String materijalNaziv;
    private String kvalitetMaterijalaKvalitet;
    private String krojacUsername;

    private List<KategorijaPodkategorijaResponse> kategorije;

    private String slikaUrl; // poseban endpoint za dohvat slike
}
