package com.example.demo.dto;


import lombok.Data;

@Data
public class KreacijaRequestDTO {
    private String slikaBase64;
    private Integer klijentId;
}

