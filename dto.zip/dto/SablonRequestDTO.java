package com.example.demo.dto;



import lombok.Data;
import java.math.BigDecimal;

@Data
public class SablonRequestDTO {
    private String slikaBase64;   // base64 string slike
    private BigDecimal cijena;
    private Integer artikalId;
}

