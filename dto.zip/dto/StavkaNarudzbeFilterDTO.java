package com.example.demo.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class StavkaNarudzbeFilterDTO {
    private Integer kolicinaMin;
    private Integer kolicinaMax;
    private BigDecimal cijenaMin;
    private BigDecimal cijenaMax;
    private LocalDate rokZaIzraduDo;
    private String statusStavkeNaziv;
    private List<String> dodaci;
    // ugniježđeni filter za ponudu
    private PonudaFilterDTO ponudaFilter;
}
