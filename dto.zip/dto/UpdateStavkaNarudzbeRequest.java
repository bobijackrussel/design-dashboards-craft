package com.example.demo.dto;


import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class UpdateStavkaNarudzbeRequest {
    private Integer kolicina; // ako se promijeni, cijena se ponovo računa
    private Integer mjereId; // može biti null = skini mjere
    private Integer krojacDrzavaPonudaId;
    private LocalDate zahtjevaniRokIzrade;
    private List<Integer> dodaciId;
}
