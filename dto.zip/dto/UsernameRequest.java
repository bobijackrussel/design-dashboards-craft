package com.example.demo.dto;


import lombok.Data;

@Data
public class UsernameRequest {

    String korisnickoIme;
}
