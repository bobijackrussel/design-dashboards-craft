package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ArtikalRequestDTO {
    private String naziv;
    private String velicina;
    private Integer kolicina;
    private String bojaNaziv;
    private String materijalNaziv;
    private String kvalitetMaterijalaKvalitet;
    private String krojacUsername;
    private String slikaBase64;
    private List<KategorijaPodkategorijaRequest> kategorije;
}

