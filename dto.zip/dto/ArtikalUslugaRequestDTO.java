package com.example.demo.dto;

import lombok.Data;


@Data
public class ArtikalUslugaRequestDTO {
    private Integer artikalId;
    private String uslugaNaziv;
}
