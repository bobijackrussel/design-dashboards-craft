package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class KreacijaResponseDTO {
    private Integer id;
    private String slikaUrl;   // endpoint za dohvat slike
    private Integer klijentId;
}
