package com.example.demo.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PonudaUslugaRequestDTO {
    private BigDecimal jedinicnaCijena;
    private Byte procenatPopusta;
    private Byte procenatZaHitnost;
    private String krojacUsername;
    private String uslugaNaziv; // vezano na usluga entitet
}
