package com.example.demo.dto;


import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class StavkaCreateInNarudzba {
    private Integer ponudaId;
    private Integer kolicina;
    private Integer mjereId; // optional
    private LocalDate zahtjevaniRokIzrade;
    private String statusStavke="U obradi";
    private Integer krojacDrzavaPonudaId;
    private List<Integer> dodaciId;
}