package com.example.demo.dto;


import lombok.Data;

import java.util.List;

@Data
public class CreateStavkaNarudzbeRequest {
    private Integer ponudaId;
    private Integer narudzbaId;
    private Integer redniBroj;
    private Integer kolicina;
    private Integer mjereId; // optional
    private Integer krojacDrzavaPonudaId;
    private List<Integer> dodaciId;
}
