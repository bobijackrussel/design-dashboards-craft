package com.example.demo.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
public class SablonResponseDTO {
    private Integer id;
    private String slikaUrl;   // endpoint za preuzimanje slike
    private BigDecimal cijena;
    private Integer artikalId;
}

