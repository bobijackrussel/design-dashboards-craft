package com.example.demo.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class MjereRequestDTO {

    private Integer id;

    @NotBlank
    private String korisnickoIme;

    @NotNull @Min(30) @Max(80)
    private Short sirinaRamena;

    @NotNull @Min(50) @Max(200)
    private Short obimGrudi;

    @NotNull @Min(50) @Max(150)
    private Short obimStruka;

    @NotNull @Min(60) @Max(200)
    private Short obimKukova;

    @NotNull @Min(50) @Max(200)
    private Short obimBokova;

    @NotNull @Min(100) @Max(220)
    private Short duzina;


}
