package com.example.demo.dto;


import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;

@Data
@AllArgsConstructor
public class ArtikalVarijacijeDTO {

    private Set<String> boje;
    private Set<String> materijali;
    private Set<String> velicine;
    private Set<String> kvalitetiMaterijala;
}
