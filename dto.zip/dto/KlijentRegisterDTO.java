package com.example.demo.dto;

import lombok.Data;

@Data
public class KlijentRegisterDTO {
    private String korisnickoIme;
    private String lozinka;
    private String ime;
    private String prezime;
    private String email;
    private String adresa;


}
