package com.example.demo.dto;

import lombok.Data;

@Data
public class KlijentResponseDTO {
    private String korisnickoIme;
    private String ime;
    private String prezime;
    private String email;
    private String adresa;
}
