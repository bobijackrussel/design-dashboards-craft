package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class KrojacDrzavaResponse {
    private Integer id;
    private String krojacUsername;
    private String drzavaNaziv;
    private BigDecimal cijenaPostarine;
}
