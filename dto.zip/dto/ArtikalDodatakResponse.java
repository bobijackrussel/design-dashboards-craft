package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ArtikalDodatakResponse {
    private Integer id;
    private Integer artikalId;
    private String dodatakNaziv;
    private BigDecimal cijena;
    private String slikaUrl; // vraća se URL za dohvat slike
}
