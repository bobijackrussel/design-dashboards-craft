package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KrojacDrzavaPonudaResponseDTO {
    private Integer id;
    private Integer ponudaId;
    private String krojacUsername;
    private String drzavaNaziv;
}
