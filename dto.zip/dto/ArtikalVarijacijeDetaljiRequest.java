package com.example.demo.dto;

import lombok.Data;

@Data
public class ArtikalVarijacijeDetaljiRequest {
    private String naziv;
    private Integer krojacId;
}
