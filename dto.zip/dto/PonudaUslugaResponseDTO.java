package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PonudaUslugaResponseDTO {
    private Integer id;
    private BigDecimal jedinicnaCijena;
    private Byte procenatPopusta;
    private Byte procenatZaHitnost;
    private String krojacUsername;

    private String uslugaNaziv; // direktno iz entiteta Usluga
}
