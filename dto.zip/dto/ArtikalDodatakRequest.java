package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ArtikalDodatakRequest {
    private Integer artikalId;
    private String dodatakNaziv;
    private BigDecimal cijena;
    private String slikaBase64; // slika se šalje kao base64
}
