package com.example.demo.dto;

import lombok.Data;

import java.util.List;

@Data
public class ArtikalFilterDTO {
    private List<String> boje;
    private List<String> materijali;
    private List<String> kvalitetiMaterijala;
    private List<String> velicine;
    private Boolean naStanju;
    private List<String> kategorije;
    private List<String> podkategorije;
    private String krojacUsername;
    private String naziv;
    private List<String> dodaci;
}
