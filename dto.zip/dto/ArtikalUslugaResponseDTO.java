package com.example.demo.dto;

import lombok.Data;


@Data
public class ArtikalUslugaResponseDTO {
    private Integer id;
    private Integer artikalId;
    private String uslugaNaziv;
}
