package com.example.demo.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class UpdateRokZaOtkazivanjeRequest {
    public LocalDate rokZaOtkazivanje; // može biti null
}
