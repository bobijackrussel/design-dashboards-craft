package com.example.demo.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class NarudzbaDTO {
    private Integer id;
    private LocalDate datum; // automatski now()
    private LocalDate datumOtkazivanja; // može biti null
    private Byte uplacenAvans;
    private LocalDate rokZaOtkazivanje; // može biti null
    private LocalDate rokZaIzradu;
    private Integer klijentId;
    private Integer krojacId;
    private String statusNarudzbeNaziv; // može biti null
    private List<StavkaNarudzbeDTO> stavke;
}
