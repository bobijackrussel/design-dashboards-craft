package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KrojacDrzavaPonudaRequestDTO {
    private Integer ponudaId;
    private String krojacUsername; // umjesto ID-ja
    private String drzavaNaziv;    // npr. "Srbija", "BiH"
}
