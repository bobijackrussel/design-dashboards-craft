package com.example.demo.dto;

import lombok.Data;

@Data
public class UpdateStatusStavkeRequest {
    // Valid values: "Pending", "Measuring", "Cutting", "Sewing", "Finishing", "Completed", "Cancelled"
    public String statusStavkeNaziv;
}
