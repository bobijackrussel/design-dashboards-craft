package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KategorijaPodkategorijaRequest {
    private String kategorijaNaziv;
    private String podkategorijaNaziv;
}
