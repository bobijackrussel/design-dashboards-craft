package com.example.demo.dto;

import lombok.Data;

@Data
public class UpdateAvansRequest {
    public Byte uplacenAvans; // 0 ili 1
}
