package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class KrojacDrzavaRequestDTO {
    private String krojacKorisnickoIme;   // šalje se username umjesto id-a
    private String drzavaNaziv;
    private BigDecimal cijenaPostarine;
}
