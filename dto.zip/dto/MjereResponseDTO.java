package com.example.demo.dto;

import java.time.LocalDate;
import lombok.Data;
@Data
public class MjereResponseDTO {
    private Integer id;
    private String korisnickoIme;
    private LocalDate datum;
    private Short sirinaRamena;
    private Short obimGrudi;
    private Short obimStruka;
    private Short obimKukova;
    private Short obimBokova;
    private Short duzina;
}
