package com.example.demo.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PonudaArtikalUslugaRequestDTO {
    private BigDecimal jedinicnaCijena;
    private Byte procenatPopusta;
    private Byte procenatZaHitnost;
    private String krojacUsername;
    private Integer brojDanaZaOtkazivanje;
    private Integer brojDanaZaIzradu;
    private ArtikalUslugaRequestDTO artikalUsluga;
}
