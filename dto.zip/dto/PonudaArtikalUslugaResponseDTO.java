package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PonudaArtikalUslugaResponseDTO {
    private Integer id;
    private BigDecimal jedinicnaCijena;
    private Byte procenatPopusta;
    private Byte procenatZaHitnost;
    private String krojacUsername;
    private Integer brojDanaZaOtkazivanje;
    private Integer brojDanaZaIzradu;

    private String uslugaNaziv; // iz ArtikalUsluga.uslugaNaziv

    private ArtikalResponseDTO artikal; // puni se iz Artikal
}
