package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class PonudaFilterDTO {
    private String krojacUsername;       // djelimična pretraga
    private List<String> usluge;          // naziv usluge
    private BigDecimal minCijena;        // donja granica cijene
    private BigDecimal maxCijena;        // gornja granica cijene

    private ArtikalFilterDTO artikalFilter; // ugniježđeni filter za artikal

    private List<String> drzave;

    private boolean uslugaFilter;
    private LocalDate rokDoIzrade;       // korisnik unosi datum do kojeg želi izradu
}
