package com.example.demo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PonudaArtikalRequestDTO {

    private BigDecimal jedinicnaCijena;
    private Byte procenatPopusta;
    private Byte procenatZaHitnost;
    private String krojacUsername;
    private String uslugaNaziv;
    private Integer brojDanaZaOtkazivanje;
    private Integer brojDanaZaIzradu;
    private ArtikalRequestDTO artikal;
}
